using System.Security.Cryptography.X509Certificates;
using UnitTestConsole;

namespace TestLab10_Ex03
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [DataRow(false, 0, 1862.5)]
        [DataRow(true, 0, 1843.875)]
        [DataRow(false, 1, 2862.5)]
        [DataRow(true, 1, 2843.875)]
        public void TestLuongTeacher(Boolean x, int y, Double rs)
        {
            Teacher teacher = new Teacher() { ID = 1, Factor = Teacher.TEACHING_ALLOWANCE_FACTOR, Name = "Tri", UnionMember = x, Seniority = y,};
            Double salary = teacher.GetSalary();
            Assert.AreEqual(rs, salary);
        }

        [TestMethod]
        [DataRow(false, 1, 11862.5)]
        [DataRow(true, 1, 11843.875)]
        [DataRow(false, 2, 71862.5)]
        [DataRow(false, 3, 51862.5)]
        public void TestLuongResearcher(Boolean x, int y, Double rs)
        {
            Researcher researcher = new Researcher() { ID = 1, Factor = Teacher.TEACHING_ALLOWANCE_FACTOR, Name = "Tri",
                                                                UnionMember = x, NumOfPaper = 1, PaperRank = y };
            Double salary = researcher.GetSalary();
            Assert.AreEqual(rs, salary);
        }
    }
}